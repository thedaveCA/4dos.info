object OperationDialog: TOperationDialog
  Left = 192
  Top = 107
  BorderStyle = bsDialog
  Caption = 'Dateiauswahl'
  ClientHeight = 178
  ClientWidth = 475
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel
    Left = 8
    Top = 15
    Width = 50
    Height = 13
    Caption = '&Quelldatei:'
  end
  object radDel: TRadioButton
    Left = 8
    Top = 48
    Width = 113
    Height = 17
    Caption = '&L'#246'schen'
    Checked = True
    TabOrder = 4
    TabStop = True
    OnClick = EnDisableOK
  end
  object radRen: TRadioButton
    Left = 8
    Top = 80
    Width = 113
    Height = 17
    Caption = '&Umbenennen in:'
    TabOrder = 5
    OnClick = EnDisableOK
  end
  object radMov: TRadioButton
    Left = 8
    Top = 112
    Width = 113
    Height = 17
    Caption = '&Verschieben nach:'
    TabOrder = 8
    OnClick = EnDisableOK
  end
  object btnOK: TButton
    Left = 152
    Top = 144
    Width = 75
    Height = 25
    Caption = 'OK'
    Default = True
    Enabled = False
    ModalResult = 1
    TabOrder = 0
    OnClick = btnOKClick
  end
  object btnCancel: TButton
    Left = 240
    Top = 144
    Width = 75
    Height = 25
    Cancel = True
    Caption = 'Abbrechen'
    ModalResult = 2
    TabOrder = 1
  end
  object edtSrc: TEdit
    Left = 64
    Top = 12
    Width = 385
    Height = 21
    TabOrder = 2
    OnChange = EnDisableOK
  end
  object btnBrowseSource: TButton
    Left = 448
    Top = 12
    Width = 21
    Height = 21
    Caption = '...'
    TabOrder = 3
    OnClick = btnBrowseSourceClick
  end
  object edtDestMov: TEdit
    Left = 120
    Top = 110
    Width = 329
    Height = 21
    TabOrder = 9
    OnChange = edtDestMovChange
  end
  object btnBrowseDestMov: TButton
    Left = 448
    Top = 110
    Width = 21
    Height = 21
    Caption = '...'
    TabOrder = 10
    OnClick = btnBrowseDestMovClick
  end
  object edtDestRen: TEdit
    Left = 120
    Top = 78
    Width = 329
    Height = 21
    TabOrder = 6
    OnChange = edtDestRenChange
  end
  object btnBrowseDestRen: TButton
    Left = 448
    Top = 78
    Width = 21
    Height = 21
    Caption = '...'
    TabOrder = 7
    OnClick = btnBrowseDestRenClick
  end
  object dlgOpen: TOpenDialog
    Options = [ofHideReadOnly, ofPathMustExist, ofEnableSizing]
    Left = 408
    Top = 144
  end
  object dlgSave: TSaveDialog
    Options = [ofHideReadOnly, ofPathMustExist, ofEnableSizing]
    Left = 440
    Top = 144
  end
end
