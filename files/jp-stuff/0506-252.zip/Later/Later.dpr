program Later;

uses
  Windows, Forms,
  MainForm in 'MainForm.pas' {Form1},
  LaterHelpers in 'LaterHelpers.pas',
  OpDialog in 'OpDialog.pas' {OperationDialog};

{$R *.RES}

var
  options: TOptions;
  bSuccess: Boolean;
  winVer: Integer;

begin
  Application.Initialize;
  Application.Title := 'Later';
  winVer := GetVersion;
  if ((winVer and $80000000) <> 0) or ((winVer and $0f) < 4)
  then begin
    Application.MessageBox('Dieses Programm ben�tigt Windows NT 4, 2000, XP, Server 2003 oder sp�ter.', nil, MB_ICONSTOP or MB_OK);
    Halt(2);
  end;
  Application.CreateForm(TForm1, Form1);
  Application.CreateForm(TOperationDialog, OperationDialog);
  options := TOptions.Create;
  options.ParseCmdLine;
  bSuccess := options.Execute;
  // Das Hauptfenster wird nur bei Bedarf angezeigt
  if options.NeedsMain
  then begin
    Application.Run;
  end
  else begin
    // Fehler beim Abarbeiten der Befehle via Errorlevel zur�ckmelden
    if not bSuccess
    then Halt(1);
  end;
end.
