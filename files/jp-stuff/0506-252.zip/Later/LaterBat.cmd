@echo off
setlocal
set params=
:loop
if %1.==. goto weiter
set params=%params% \"%~1\"
shift
goto loop
:weiter
runas /user:Chef "Later %params%"
