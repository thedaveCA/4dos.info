/* CPDESC.CMD copies the 4DOS/4OS2 description of one file to the       */
/*            description of another file or group of files.            */
/*                                                                      */
/* Version 1.0 -- June 26, 1995 -- Gene Pizzetta, CompuServe 72060,505  */
/*    Initial release.                                                  */

Call rxFuncAdd "SysLoadFuncs", "REXXUTIL", "SysLoadFuncs"
call sysloadfuncs

Vers = 10       /* current version */
SubVers = ' '   /* current revision level */

/* Parse file arguments */
parse upper arg file1 file2

if file2 = '' | file1 = '/?' | file1 = '-?' then
do
  say
  say 'CPDESC    Version' CONV_VERS(Vers,1)SubVers
  say '�����������������������������������������������������������'
  say 'Copies a file description from one file to others.'
  say '�����������������������������������������������������������'
  say 'Usage:'
  say
  say '  'PRG_NAME()' source target'
  say
  say 'The 4OS2 description of the source file will be copied to'
  say 'the description of the target files.  Both filenames are'
  say 'required.'
  say
  say 'Wildcards may be used in the target name, but not in the'
  say 'source name.'
  say '�����������������������������������������������������������'
  exit
end

Bell = x2c(07)
DFile = 'DESCRIPT.ION'

TmpFile = 'DESCRIPT.$$$'
TmpDir=value(tmp,,os2environment)
TmpFile = TmpDir || TmpFile

signal on NOTREADY                      /* trap file errors */

/* Get 4OS2 escape character */
'set escchar=%=%='
EscChar=value(escchar,,os2environment)
'unset escchar'

Call CHKFILES                   /* Make sure the two files exist */

say '  Copying description for' file1 'to' file2 '...'

/* Temporarily disable certain 4OS2 expansions, ask 4OS2 to set the     */
/* description into the environment, ask REXX to grab the variable from */
/* the environment, and then unset it.                                  */

'*setdos /x-45678'
'*set outdesc=%@descript['file1']'
'*setdos /x0'

FDesc=value(outdesc,,os2environment)

if FDesc <> '' then               /* Avoid error message if null description */
do
  '*unset outdesc'
end

call ESC_ESC(EscChar)             /* Handle embedded 4OS2 escape characters */
call ESC_ESC('`')                 /* Handle embedded grave accents */

'*ECHO `'FDesc'` >'TmpFile        /* Write description to a temporary file */

do i = 1 to TFiles.0
  CurFile = translate(filespec("name",TFiles.i))  /* Get current filename */
  if CurFile = DFile then iterate       /* Skip the DESCRIPT.ION file */
  if words(TFiles.i) > 1 then           /* Look for embedded spaces */
  do
    TFiles.i = '"'TFiles.i'"'           /* If so, surround with quotes */
  end
  '*DESCRIBE' TFiles.i '<'TmpFile       /* Get the description to DESCRIBE */
end

'*DEL /Q' TmpFile                 /* Finally, delete the temporary file */

EXIT

/* ======================= Subroutines ======================= */


/* Make one and only one file matches each filename */
/* ------------------------------------------------ */

CHKFILES:

  /* Handle filenames with embedded spaces */
  if pos('"',file1,1) <> 0 then call ESPACE

  call SysFileTree file1 , 'SFiles', 'FO' , '*****'
  if SFiles.0 = 0 then             /* make sure source file exists */
  do
    say Bell'  'file1' file not found.'
    exit
  end

  if pos('"',file2) <> 0 then      /* look for a long filename */
  do
    file2 = strip(file2,'B','"')
  end

  call SysFileTree file2 , 'TFiles', 'FO' , '*****'
  if TFiles.0 = 0 then             /* make sure target file exists */
  do
    say Bell'  'file2' file not found.'
    exit
  end

  if SFiles.0 > 1 then            /* allow only one matching source file */
  do
    say Bell'  Source filename cannot be ambiguous.'
    exit
  end

if words(file1) > 1 then        /* look for embedded spaces */
do

  /* file1 = '"'file1'"' */
  /* A limitation of 4OS2 does not allow the use of double-quotes */
  /* for filenames with embedded spaces when SETDOS /X-7 is used. */
  /* I haven't found a way around this problem when using the     */
  /* @DESCRIPT[] function to obtain a file description.  Failure  */
  /* to use the /X-7 parameter could unceremoniously crash the    */
  /* program, so I have decided to disallow embedded spaces in    */
  /* source file and exit gracefully.                             */

  say Bell'  Source filenames cannot contain spaces.'
  exit
end

if words(file2) > 1 then        /* look for embedded spaces */
do
  file2 = '"'file2'"'
end

RETURN


/* Insert 4DOS/4OS2 escape characters */
/* ---------------------------------- */

ESC_ESC:
  arg SearchChar                            /* Character to escape */
  StartPos = 1                              /* Start at beginning of string */
  do forever
    EscPos = pos(SearchChar,FDesc,StartPos)  /* look for requested chars */
    if EscPos = 0 then leave
    FDesc = insert(EscChar,FDesc,EscPos-1) /* Insert leading escape char */
    StartPos = EscPos + 3                   /* Move past escape char .. */
    iterate                                 /* .. and keep looking */
  end
RETURN


/* Get source filenames with embedded spaces */
/* ----------------------------------------- */

ESPACE:

  FEnd = pos('"',file2,2)             /* Find end of filename */
  file1 = file1 Left(file2,FEnd)      /* Get rest of filename */
  file2 = delstr(file2,1,FEnd+1)      /* Delete source name from target name */
  file1 = strip(file1,'B','"')        /* Strip off quotes */

RETURN


/* Get name of current program */
/* --------------------------- */

PRG_NAME:

  parse source . . PName
  PName = filespec('name',PName)
  PName = left(PName,pos('.',PName)-1)

RETURN PName


/* Convert version number to correct format */
/* ---------------------------------------- */

CONV_VERS:

  arg PVers,OffSet
  OffSet = 10 ** OffSet
  PVers = PVers%OffSet'.'PVers//OffSet

RETURN PVers


/* Trap for file errors */
/* -------------------- */

NOTREADY:

  say '  File error on line' sigl
  say '  'sourceline(sigl)

EXIT

