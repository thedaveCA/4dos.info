/* ZDESC.CMD  reads 4OS2 DESCRIPT.ION files and creates MAKEDESC.BTM    */
/*            batch files.  The batch files may be stored in archives   */
/*            and then run to restore the file descriptions after the   */
/*            files are extracted back to disk.                         */
/*                                                                      */
/* Version 1.0 -- March 26, 1995 -- Gene Pizzetta, CompuServe 72060,505 */
/*    Initial release.                                                  */
/* Version 1.1 -- April 8, 1995 -- GP                                   */
/*    Indented MAKEDESC.BTM's messages slightly for aesthetics.  Did    */
/*    not restore current directory properly, if run from the root      */
/*    directory.                                                        */
/* Version 1.2 -- April 23, 1995 -- GP                                  */
/*    To eliminate the restriction on descriptions with embedded double */
/*    quotes Howard Goldstein suggested piping the description to the   */
/*    DESCRIBE command in MAKEDESC.BTM.  That worked, but piping proved */
/*    to be VERY slow.  Well, why not redirection from a temporary      */
/*    file, he said.  That also worked, and with no perceptable speed   */
/*    penalty (at least on my machine).  Thanks, Howard.  MAKEDESC.BTM  */
/*    now writes a temporary file named DESCRIPT.$$$ to feed the        */
/*    DESCRIBE command and now handles file descriptions with embedded  */
/*    double-quotes, or any other special characters.                   */
/* Version 1.3 -- June 26, 1995 -- GP                                   */
/*    Modifications to CONV_VERS.  Added PRG_NAME.                      */

Call rxFuncAdd "SysLoadFuncs", "REXXUTIL", "SysLoadFuncs"
call sysloadfuncs

Vers = 13       /* current version */
SubVers = ' '   /* current revision level */

/* Parse option to a single letter "R" or "S", or garbage */
parse upper arg opt
if (pos('R',opt) <> 0) | (pos('S',opt) <> 0) then opt = translate(opt,,'-/')

if opt <> '' & opt <> 'S' & opt <> 'R' then
do
  say
  say 'ZDESC    Version' CONV_VERS(Vers,1)SubVers
  say '�����������������������������������������������������������'
  say 'Creates MAKEDESC.BTM batch files to allow restoral of 4OS2'
  say 'file descriptions from ZIP and other archives.'
  say '�����������������������������������������������������������'
  say 'Usage:'
  say
  say '  'PRG_NAME()' {S|R}'
  say
  say 'If the "S" or "R" option is given (either with or without'
  say 'a leading "/" or "-"), ZDESC will recurse through all'
  say 'subdirectories below the current directory creating'
  say 'MAKEDESC.BTM files.'
  say '�����������������������������������������������������������'
  exit
end

Bell = x2c(07)

signal on NOTREADY                      /* trap file errors */

DFile = 'DESCRIPT.ION'
OFile = 'MAKEDESC.BTM'
ODesc = 'Adds 4OS2 file descriptions'
TmpFile = 'DESCRIPT.$$$'

DirName ='*'
CurDir = directory()
CurDir = filespec('P',CurDir'\')
if CurDir = '\\' then CurDir = '\'

/* Get 4OS2 escape character */
'set escchar=%=%='
EscChar=value(escchar,,os2environment)
'unset escchar'

/* Do current directory */
call GETDESC

/* At this point we had either an S or R option, or no option */
if opt <> '' then call DOSUBS           /* Subdirectories were requested */

say ' ZDESC done.'

EXIT


/* ======================= Subroutines ======================= */


/* Do subdirectories */
/* ----------------- */

DOSUBS:

call SysFileTree DirName , 'Dirs', 'DSO'

if Dirs.0 = 0 then RETURN

do j = 1 to Dirs.0
  NxtDir = filespec('P',Dirs.j'\')
  'cd' NxtDir
  call GETDESC
end

'cd' CurDir

RETURN


/* Main subroutine for creating MAKEDESC.BTM file */
/* ---------------------------------------------- */

GETDESC:

say ' 'directory()

/* Make sure a DESCRIPT.ION file exists */
call SysFileTree DFile , 'Files', 'FO' , '*****'
if Files.0 = 0 then             /* make sure at least one filename matches */
do
  say Bell'  "'DFile'" file not found'
  RETURN
end

/* Make sure an existing DESCRIPT.ION file has something in it */
if lines(DFile) = 0 then
do
  say Bell'  "'DFile'" file is empty'
  call stream DFile,'C','CLOSE'
  RETURN
end

/* If MAKEDESC.BTM already exists, delete it */
OldFile = stream(OFile,'c','query exists')
if OldFile <> "" then
do
  call sysfiledelete OldFile
  if result <> 0 then
  do
    say Bell'  Unable to delete existing' OldFile 'file'
    EXIT
  end
end

/* Read lines from DESCRIPT.ION file into an array */
ILine.0 = 0
i = 0

do while lines(DFile) > 0
  ILine.0 = ILine.0 + 1
  i = i + 1
  ILine.i = linein(DFile)
  parse var ILine.i FName.i FDesc.i

  /* Skip existing description of our MAKEDESC.BTM file */
  if FName.i = OFile then
  do
    ILine.0 = ILine.0 - 1
    i = i - 1
    iterate
  end

  /* Handle filenames with embedded spaces */
  if pos('"',FName.i,1) <> 0 then call ESPACE
end

call lineout OFile,'REM Restores 4OS2/4DOS file descriptions for files in this archive'
call lineout OFile,'*@ECHO OFF'
call lineout OFile,'*ECHO `  Writing descriptions ...`'

do i = 1 to ILine.0
  call ESC_ESC(EscChar)       /* Handle embedded 4OS2 escape characters */
  call ESC_ESC('`')           /* Handle embedded grave accents */
  /* Write line to BTM that echos description to temporary file, and */
  /* then feeds the description from the file to the DESCRIBE command. */
  call Lineout OFile,'*ECHO `'FDesc.i'` >'TmpFile
  call Lineout OFile,'*DESCRIBE' FName.i '<'TmpFile
end

/* Delete our temporary file, add a description for our BTM file */
call lineout OFile,'*DEL /Q' TmpFile
call lineout OFile,'*DESCRIBE' OFile '"'ODesc'"'
call lineout OFile,'*ECHO `  Done`'
call stream OFile,'C','CLOSE'

/* Also write the description to our current DESCRIPT.ION file */
call lineout DFile,OFile ODesc
call stream DFile,'C','CLOSE'

RETURN


/* Insert 4DOS/4OS2 escape characters */
/* ---------------------------------- */

ESC_ESC:
  arg SearchChar                            /* Character to escape */
  StartPos = 1                              /* Start at beginning of string */
  do forever
    EscPos = pos(SearchChar,FDesc.i,StartPos)  /* look for requested chars */
    if EscPos = 0 then leave
    FDesc.i = insert(EscChar,FDesc.i,EscPos-1) /* Insert leading escape char */
    StartPos = EscPos + 3                   /* Move past escape char .. */
    iterate                                 /* .. and keep looking */
  end
RETURN


/* Get filenames with embedded spaces */
/* ---------------------------------- */

ESPACE:

  FEnd = pos('"',ILine.i,2)           /* Find end of filename */
  FName.i = Left(ILine.i,FEnd)        /* Get entire filename */
  FDesc.i = delstr(ILine.i,1,FEnd+1)  /* Delete filename from description */

RETURN


/* Get the name of the current program */
/* ----------------------------------- */

PRG_NAME:

  parse source . . PName
  PName = filespec('name',PName)
  PName = left(PName,pos('.',PName)-1)

RETURN PName


/* Convert version number to correct format */
/* ---------------------------------------- */

CONV_VERS:

  arg PVers,OffSet
  OffSet = 10 ** OffSet
  PVers = PVers%OffSet'.'PVers//OffSet

RETURN PVers


/* Trap for file errors */
/* -------------------- */

NOTREADY:

  say '  File error on line' sigl
  say '  'sourceline(sigl)

EXIT

