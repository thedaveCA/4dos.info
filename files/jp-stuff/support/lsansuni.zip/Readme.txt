This document contains the End User Licensing Agreement, and instructions concerning font installation on the various Windows platforms.


Microsoft TrueType Fonts
END-USER LICENSE AGREEMENT FOR MICROSOFT SOFTWARE
---------------------------------------------------

IMPORTANT - READ CAREFULLY: This Microsoft End-User License Agreement ("EULA") is a legal agreement between you (either an individual or a single entity) and Microsoft Corporation for the Microsoft software accompanying this EULA, which includes computer software and may include associated media, printed materials, and "on-line" or electronic documentation ("SOFTWARE PRODUCT" or "SOFTWARE"). By exercising your rights to make and use copies of the SOFTWARE PRODUCT, you agree to be bound by the terms of this EULA. If you do not agree to the terms of this EULA, you may not use the SOFTWARE PRODUCT.
SOFTWARE PRODUCT LICENSE
The SOFTWARE PRODUCT is protected by copyright laws and international copyright treaties, as well as other intellectual property laws and treaties. The SOFTWARE PRODUCT is licensed, not sold.
1. GRANT OF LICENSE. This EULA grants you the following rights:
�	Installation and Use. You may install and use an unlimited number of copies of the SOFTWARE PRODUCT.
�	Reproduction and Distribution. You may reproduce and distribute an unlimited number of copies of the SOFTWARE PRODUCT;  provided that each copy shall be a true and complete copy, including all copyright and trademark notices, and shall be accompanied by a copy of this EULA.  Copies of the SOFTWARE PRODUCT may not be distributed for profit either on a standalone basis or included as part of your own product.
2.	DESCRIPTION OF OTHER RIGHTS AND LIMITATIONS. 
�	Limitations on Reverse Engineering, Decompilation, and Disassembly. You may not reverse engineer, decompile, or disassemble the SOFTWARE PRODUCT, except and only to the extent that such activity is expressly permitted by applicable law notwithstanding this limitation.
� Restrictions on Alteration.  You may not rename, edit or create any derivative works from the SOFTWARE PRODUCT, other than subsetting when embedding them in documents.
�	Software Transfer. You may permanently transfer all of your rights under this EULA, provided the recipient agrees to the terms of this EULA.
�	Termination. Without prejudice to any other rights, Microsoft may terminate this EULA if you fail to comply with the terms and conditions of this EULA. In such event, you must destroy all copies of the SOFTWARE PRODUCT and all of its component parts.
3. COPYRIGHT. All title and copyrights in and to the SOFTWARE PRODUCT (including but not limited to any images, text, and "applets" incorporated into the SOFTWARE PRODUCT), the accompanying printed materials, and any copies of the SOFTWARE PRODUCT are owned by Microsoft or its suppliers. The SOFTWARE PRODUCT is protected by copyright laws and international treaty provisions. Therefore, you must treat the SOFTWARE PRODUCT like any other copyrighted material.
4.	U.S. GOVERNMENT RESTRICTED RIGHTS. The SOFTWARE PRODUCT and documentation are provided with RESTRICTED RIGHTS. Use, duplication, or disclosure by the Government is subject to restrictions as set forth in subparagraph (c)(1)(ii) of the Rights in Technical Data and Computer Software clause at DFARS 252.227-7013 or subparagraphs (c)(1) and (2) of the Commercial Computer Software-Restricted Rights at 48 CFR 52.227-19, as applicable. Manufacturer is Microsoft Corporation/One Microsoft Way/Redmond, WA 98052-6399. 
LIMITED WARRANTY
NO WARRANTIES. Microsoft expressly disclaims any warranty for the SOFTWARE PRODUCT. The SOFTWARE PRODUCT and any related documentation is provided "as is" without warranty of any kind, either express or implied, including, without limitation, the implied warranties or merchantability, fitness for a particular purpose, or noninfringement. The entire risk arising out of use or performance of the SOFTWARE PRODUCT remains with you.
NO LIABILITY FOR CONSEQUENTIAL DAMAGES. In no event shall Microsoft or its suppliers be liable for any damages whatsoever (including, without limitation, damages for loss of business profits, business interruption, loss of business information, or any other pecuniary loss) arising out of the use of or inability to use this Microsoft product, even if Microsoft has been advised of the possibility of such damages. Because some states/jurisdictions do not allow the exclusion or limitation of liability for consequential or incidental damages, the above limitation may not apply to you.
MISCELLANEOUS
If you acquired this product in the United States, this EULA is governed by the laws of the State of Washington.
If this product was acquired outside the United States, then local laws may apply.
Should you have any questions concerning this EULA, or if you desire to contact Microsoft for any reason, please contact the Microsoft subsidiary serving your country, or write: Microsoft Sales Information Center/One Microsoft Way/Redmond, WA  98052-6399.






INSTALLING FONTS
________________
----------------


Windows95
---------

To add a new font to your computer:

1) Open the font folder from the Control Panel.

2) On the File menu, click Install New Font.

3) Click the drive and folder that contain the fonts you want to add.

4) Double-click the icon for the font you want to add.


Tips

To select more than one font to add, press and hold down the CTRL key, and then click the fonts you want. 

To select a range of fonts in the list, press and hold down the SHIFT key while dragging the cursor over the fonts.

To add fonts from a network drive without using disk space on your computer, make sure Copy Fonts To Windows Folder is not checked.





Windows 3.1x
------------

To add fonts to your computer:

1) In the Control Panel window, choose the Fonts icon. The fonts already installed are listed in the Installed Fonts box. 

2) Choose the Add button. 

3) In the Add Fonts dialog box, select the font you want to add. You can add more than one font at a time. You can also select all the fonts listed by choosing the Select All button. If the font is not located in the current drive or directory, select the drive and directory where it is located. If the font you want to add is on someone else's computer, you can use the Network button to browse through and connect to shared directories on other computers. 

4) If you are low on disk space and want to use the fonts directly from the directory (network or local) where they are located, without copying the font files to the Windows directory, clear the Copy Fonts To Windows Directory check box. 

5) Choose the OK button. 

6) In the Fonts dialog box, choose the Close button. 

For help with the Fonts and Add Fonts dialog boxes, choose the Help button or press F1 while using the dialog boxes. 




Windows NT
----------

To add fonts to your computer:

1) In the Control Panel window, choose the Fonts icon. The fonts already installed are listed in the Installed Fonts box. 

2) Choose the Add button. 

3)In the Add Fonts dialog box, select the font you want to add. If the font is not located in the current drive or directory, select the drive and directory where it is located. You can add more than one font at a time. You can also select all the fonts listed by choosing the Select All button. 

4) If you are low on disk space and want to use the fonts directly from the directory (network or local) where they are located, without copying the font files to the \systemroot\SYSTEM directory, clear the Copy Fonts To Windows Directory check box. 

5) Choose the OK button. 

6) Choose the Close button. 

For help with the Fonts and Add Fonts dialog boxes, choose the Help button or press F1 while using the dialog boxes.



