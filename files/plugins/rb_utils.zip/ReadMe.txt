           RB_UTILS Plugin for 4NT and Take Command.
           =========================================
                        Version 1.4


IMPORTANT NOTE: I am making this plugin available for anyone to
                download and use as they wish, but you do so at 
                your own risk.  I can give no warranty for it
                and I accept no responsibility for any
                consequences of its use.

==================================================================
The RB_UTILS plugin provides the following functionality for 4NT
and Take Command:

  Internal Varaible:   _USERID
  
  Internal Functions:  @ISDATE, @ISTIME, @MONTHNUM, @ROT13

  New Command:         MOUSEBUTTONS
  
  Modified Command:    DELAY (4NT Only)
==================================================================

1.  _USERID returns the User Name of the user in whose context
    4NT or Take Command is currently running.
    
    This is the same name as in the environment variable
    %USERNAME, but it is more difficult for a user to override.
    For example, if you have a batch file that you wish to be run
    only by a user called foobar, it is easy for any other user
    to:

        set USERNAME=foobar
     
    and a check in your batch file for %username would match.

    Even though a user could do:
    
        set _USERID=foobar
      
    the following batch fragment would ensure that you checked the
    value returned by the internal varaible:
    
        @echo off
        setlocal
                
        unset /q _userid
        
        if %_userid EQ foobar ...



2.  @ISDATE[string[,format]]: Returns 1 if string is a valid date in
                              the range 1980-01-01 to 2099-12-31
                              inclusive. Returns 0 otherwise.

    @ISDATE checks that the supplied string is a valid date and is
    within the range supported by 4NT/TC's date handling functions.
    The Year may be specified as two or four digits.  Two digit years
    from 80 to 99 are interpreted as 1980..1999; values from 0 to 79
    are interpreted as 2000..2079. Most non-numeric printing
    characters are accepted as field separators.

    The supplied date is validated against the system's default date
    format unless you use the optional 'format' parameter, which
    takes one of the following values:

          0 - System default
          1 - USA (mm/dd/yy)
          2 - Europe (dd/mm/yy)
          3 - Japan (yy/mm/dd)
          4 - ISO 9601 (yyyy/mm/dd)


    Notes:
    1. Although I've tried to match 4NT/TC's behaviour in the handling
       of date strings, the acceptance by @ISDATE of a particular field
       separator is no guarantee that the same separator will be
       accepted by 4NT/TC's built-in date handling functions.

    2. If you use an illegal value for the 'format' parameter it will
       be silently ignored.


3.  @ISTIME[HH:MM[:SS][,format]]: Returns 1 if HH:MM[:SS] is a valid
                                  time. Returns 0 otherwise.

    @ISTIME checks that the supplied value is a valid time.  Most
    non-numeric printing characters are accepted as field separators.

    The supplied time will validated as 12 or 24 hour format depending
    on the system default setting for time display, unless you specify
    the optional format parameter which takes one of the following
    values:

         0  - System default
         12 - 12 hour format
         24 - 24 hour format

    If you use an illegal value for the 'format' parameter it will be
    silently ignored.


4.  @MONTHNUM[MonthName]:  Returns the month number for MonthName
                           (in long or short format), or returns
                           0 if it's not a valid month name.

    @MONTHNUM converts a supplied month name (e.g. "Jan" or
    "January") into the appropriate number representing the month
    of the year.  If the supplied string is not a valid month
    name then zero is returned.
    
    Examples:
 	
 	   c:\>echo %@monthnum[feb]
	   2

	   c:\>echo %@monthnum[August]
	   8

	   c:\>echo %@monthnum[foobar]
	   0



5.  @ROT13[string]:  Performs a ROT13 encryption on the
                     supplied string.

    @ROT13 provides a simple encryption algorithm that rotates the
    alphabet by 13 places, so A becomes N, B becomes O etc. Obviously
    it�s useless as a secure cipher, but it�s handy to obscure, for
    example, your e-mail address in a newsgroup/forum posting to help
    prevent it being "harvested".

    The ROT13 cipher is self-inverse, so text that you've encoded
    with @ROT13 can be decoded by using @ROT13 again on the encoded
    text.

 
6.  MOUSEBUTTONS reverses and restores the meaning of the right and
    left mouse buttons.
    
    Usage: MOUSEBUTTONS [/Q]  Normal|Swap
               /Q(uiet)

    The normal meaning of the left and right mouse buttons can be
    reversed via the control panel, but this command allows the same
    thing to be accomplished from the command line.
    
    The /Q option suppresses normal messages (but not errors)
    and is mainly intended for use in batch files.
    
    
7.  DELAY (4NT ONLY) - Pause for a specified length of time.

    Usage:  DELAY [/B /F /M] [seconds]
               /B(reak): Exit on any keystroke
               /F(lush): Clear keystrokes buffer when delay ends
               /M(illiseconds): Argument is in milliseconds
               seconds:  Number of seconds to delay


    An extra option (/F) has been added to the DELAY command
    which clears out the keystrokes buffer at the end of the
    delay.  This prevents any keys that were hit during the delay
    period from appearing at the command prompt or affecting
    subsequent commands in a batch file.
    
    
===================================================================
"4NT" and "Take Command" are registered Trade Marks of JP Software.