     REM  - 5 Aliase f�r vergleichende Operationen (z. B. DIR, COPY...) -

     REM .OT. -> Older Than
     REM .NT. -> Newer Than
     REM .EQ. -> Equal
     REM .OE. -> Older or Equal
     REM .NE. -> Newer or Equal

     REM Syntax: .??. Befehl Tagesanzahl
     REM z. B.:  .oe. DEL 5 L�scht alle Files, die �lter oder gleich 5 Tage sind

     alias .ot. =`%2 /[d%@makedate[0],%@makedate[%@eval[%@date[%_date]-%1-1]]] %3&`
     alias .nt. =`%2 /[d-%@eval[%1-1]] %3&`
     alias .eq. =`%2 /[d-%1,0] %3&`
     alias .oe. =`%2 /[d%@makedate[0],%@makedate[%@eval[%@date[%_date]-%1]]] %3&`
     alias .ne. =`%2 /[d-%1] %3&`
