This COMMAND2.COM is Command 2.41 made by Fokke Post patched for FAT16 by Okei
