                              4NT v6.0

                     README.TXT -- September 2004

                          JP Software Inc.
                            P.O. Box 328
                     Chestertown, MD 21620, USA

                           (410) 810-8818
                         fax (410) 810-0026
                       Email sales@jpsoft.com
                       Web http://jpsoft.com


Greetings, and thanks for trying 4NT!

This file contains a variety of information you should read before using
4NT, including:

      New Version Overview
      Installation Notes
      Trial Version Basics
      Giving Copies to Others to Try
      Files Included with this Version
      Technical Support and Downloads
      Legal Notices

Other information is available in other files:

      For ...                                See ...
      -----------------------------------    ------------
      Introduction and Installation Guide    GUIDE.PDF
      Order form                             ORDERS.TXT


NEW VERSION OVERVIEW
--------------------

Since the last major release we've added over 200 new features, commands,
switches, variables, and other enhancements!  The complete list of new 
features is in the "What's New" topic in the help file.


INSTALLATION NOTES
------------------

   Our products are generally distributed as EXE files which install the
   product when run.  For complete details on installation, see GUIDE.PDF.
   
   If you are installing a purchased copy of 4NT from a CD-ROM, you can 
   install the files manually by copying them from the appropriate 
   directory on the CD if you wish.

   You can view any of the documentation files on-line, or copy them to
   your printer.


Trial Version Basics
--------------------

   We distribute trial or "shareware" versions of our software to allow you
   to "try before you buy".  Most users obtain trial versions by downloading
   them.  You might also have one if a friend gave you a copy of their
   software -- as long as they don't  give you their serial number and
   registration key (which would be illegal), the software they gave you
   will operate as a trial version.
 
   We explain here how trial versions work because we believe that full
   disclosure of what you can expect from your software is the best policy
   for both you and us.  Our timing mechanism is designed to give you a
   fair opportunity to try our software, order it, and receive it without
   significant restrictions on use.  It's also designed to make sure that
   use of the software becomes restricted if you exceed the normal
   evaluation period.
   
   Trial versions of our products are fully functional evaluation copies
   which are not "crippled" or feature-limited in any way except for the
   trial timing mechanism described here.


Trial Version Timing
--------------------

   4NT and Take Command give you a 30-day evaluation period.  The number
   of days remaining in the evaluation period is displayed when you start
   the program, and can be redisplayed at any time with the VER /R command.
   During the last 5 days of the evaluation period, a short two-tone beep
   draws your attention to the signon message.
   
   Once you have reached the evaluation limit days, your use of the software
   is restricted by limiting the number of commands you can enter before the
   program exits automatically and must be restarted.  You are advised of the
   usage restriction each time you start the program.  There is also a delay
   each time the program starts.

   Once use is restricted the software will also sound a three-tone sequence
   of beeps each time it is started.


Registering Your Copy
---------------------

   When you purchase a new or upgrade copy of 4NT, you will receive an email 
   with an attached file named 4NT.KEY  Simply double click on the 4NT.KEY 
   attachment (or save it to the disk and type the file name at the command
   prompt) to register 4NT with your name and serial number.  (A popup may 
   appear asking if you want to add the information in 4NT.KEY to the 
   registry; click on Yes to continue.)

   If you ordered a CD from one of our resellers, your 4NT.KEY file will be
   in the \4NT directory.

   If you are running 4NT at the time you load 4NT.KEY, your registration 
   information won't appear until you exit and restart 4NT.

   Remember to save your 4NT.KEY file in a safe place in case you need to
   reinstall 4NT.  If you have lost your registration key, you can request
   a replacement key by contacting JP Software at sales@jpsoft.com, or at 
   one of the addresses listed at the start of this file.


Giving Copies to Others to Try
------------------------------

   We know many of our customers may want to give a copy of one of our 
   products to a friend or colleague to try.
   
   We encourage you to share your purchased copy of our software with
   individuals you know personally.  The only restriction is that you must
   use the simple approach described here to avoid violating your license
   agreement or disclosing the registration key (for which you paid!) to
   others.
   
   To give a copy of your software to someone else for evaluation purposes,
   simply let them borrow or make a copy of your CD (or the desired
   subdirectory from the CD), or downloaded electronic purchase.  When your
   friend or colleague installs the software you've passed along to them in
   this way, without your serial number and registration key, the program
   will automatically become a trial version using the system described
   earlier in this file.  The recipient may then decide whether to purchase
   the software under our normal trial version policies.
   
   Please note that under our license and trial version policies there are
   also some things you may NOT do:
   
      - You may not give the other person your registration key, as this is
        private and represents the license you paid for (giving them to
        others is a violation of your license agreement).
   
      - You may not place copies of your purchased copy of our software on
        any Internet or other electronic distribution site, or in any user
        group or other shareware library, or distribute them to the public
        at large in any way.  This policy only allows you to distribute
        copies to friends and colleagues you know personally and privately.
   
   PLEASE NOTE:  This policy allows for only one level of distribution;
   those who receive copies of your purchased software for trial use under
   this policy may NOT further redistribute those copies to their friends
   and colleagues.

   If you need a true trial copy for general distribution, download one
   from our web site at http://jpsoft.com/.


FILES INCLUDED
--------------

   The following files are included with 4NT 6.0:

         4NT.EXE           4NT program file
         BCHILD.DLL        Batch debugger support DLL
         EXAMPLES.BTM      Sample batch file demonstrating the use of
                             variable functions and internal variables
         GUIDE.PDF         Introduction and Installation Guide
         IPWORKS6.DLL      Internet functions support DLL
         IPWSSL6.DLL       Internet SSL functions support DLL
         JPHELP.CHM        4NT online help
	 LANGUAGE.DLL      Localized text for internal messages
         ORDERS.TXT        Order form for fax and mail orders
         README.TXT        This file
         SHRALIAS.EXE      Utility program for retention of global
                             alias and history lists
         TAKECMD.DLL       Shared DLL for 4NT and Take Command


TECHNICAL SUPPORT AND DOWNLOADS
-------------------------------

   Complete details on technical support, including support plans and 
   terms and conditions, are on our web site.

   Standard, no-charge support is available through our online support 
   forum, where our support personnel can read and respond to your 
   messages, and other users can respond as well.  The forum is accessible
   via several methods; for complete details and access links see the 
   support area of our web site at http://jpsoft.com/.

   We also offer a paid support option which includes automatic upgrades
   and support by private email or telephone.

   If the support forum is not accessible to you, or you need to include 
   confidential information in your support request, you can also contact 
   us at support@jpsoft.com.

   Technical support messages should always be sent as standard ASCII
   text.  Please do not transmit attached files, binary files, screen
   images, or any file over 10K bytes in size to our technical support 
   addresses unless asked to do so by our support staff.

   To download JP Software files, including maintenance updates and
   trial versions, visit:

      >> Our web site at http://jpsoft.com

      >> Our ftp site at ftp://jpsoft.com


LEGAL STUFF
-----------

Copyright 2004, JP Software Inc., All Rights Reserved.  Published by JP
Software Inc., P.O. Box 328, Chestertown, MD 21620, USA
Phone 410-810-8818, Fax 410-810-0026.

Take Command is a registered trademark of JP Software Inc.  4NT is JP
Software Inc.'s trademark for its of character-mode command processor.
JP Software, jpsoft.com, and all JP Software designs and logos are also 
trademarks of JP Software Inc.  Other product and company names are 
trademarks of their respective owners.
