:: ************************* 4XALIAS ***********************************
:: This is the start of sample aliases to make life easier for you.
:: These aliases are culled from diverse alias files and examples
:: floating around, and a few are my own. If you want to add your
:: own best aliases to 4XBTM, send them to me, and they may be
:: included if they are not to specialized only for your own needs
:: in my opinion (see 4XBTM.DOC for my adress).
:: *********************************************************************

:: If you have experience with 4DOS, you probably have already
:: aliased a lot of your commands, so be careful to check these
:: aliases for duplication of functions already aliased!
::
:: If you are a beginner, these aliases will give you a start to
:: realize the full power of 4DOS on your system. Put this file in
:: your 4DOS directory and load it from autoexec.bat with a line like:
::
:: alias /r c:\4dos\4xalias.als
::
:: If you have your own alias file already, copy the aliases you want
:: to use to your own alias file and keep 4xalias.als for reference.
:: In some cases you will have to adapt the path or filename to your needs.
::
:: Note that batches and programms may behave differently if you have
:: aliased DOS commands. If you want to use the original, unaliased
:: command from the command line, precede them with "*" like:
:: *copy *.* /foobar

:: First a few very simple key macros, which are very useful on my system.

:: Keymacro: This one calls the help function of another DOS.
:: Change the path according to your system. (Taken from 4DOS Manual)
@@Alt-F1=c:\dos\help.com
::
:: This one simply clears the screen. (Taken from 4DOS Manual)
@@Ctrl-F1=cls

:: Keymacro: This leaves a 4DOS shell. I can shell to DOS from my
:: editor with Alt-F12, look something up in 4DOS help with F1, and
:: then I am back in my editor with Alt-F12. (Taken from 4DOS Manual)
@@Alt-F12=exit

:: This keymacro starts the XAD screen saver
@@Alt-X=XAD /r

:: Another way to get to the not so comfortable help system:
oldhelp=c:\windows\oldmsdos\help.com %1 %2 %3

:: Now we do a little directory jumping. Note that 4DOS5 now has
:: function keys to go to recently used dirs.

:: Up one level...
.*.........=%0.\
-*---------=%0.\
:: Root dir
#=*cd \

:: Change the drive more easily...
@@Alt-A=A:
@@Alt-B=B:
@@Alt-C=C:
@@Alt-D=D:
@@Alt-E=E:
@@Alt-F=F:
@@Alt-G=G:
@@Alt-H=H:
@@Alt-I=I:
@@Alt-J=J:

:: To help those stupid programs that explicitly call command.com
command*.com=%comspec

:: Now this one should be on every system. Why have a computer
:: if it can't calculate ? (From 4DOS example file ALIASES)
calc=`echo The answer is:  %@eval[%&]`

:: Use these if you want to be asked before files are overwritten
:: or deleted...
cop*y=*copy /r %&
mov*e=*move /r %&
del=*del /p %&

:: And use these if you want to selectively copy, move or delete
:: files. Existing files are only copied / moved, if they are older...
scopy=select *copy /u (%1) %2
smove=select *move /ud (%1) %2
sdel=(iff %# == 0 then %+ set _filspec=*.* %+ else set _filspec=%1 %+endiff) %+select /d *del (%_filspec) %+unset /q _filspec
:: for compatibility: runs XAT.BTM for selectively changing file attributes.
satt=xat %&

:: There are lots of aliases for showing the directory in different ways.
:: On my system they all start with d and have a lot of parameters.

:: Sorted, attributes, without dots...
d=*dir /a/o:gn/v/p/j/t %&
:: 2 Columns...
d2=*dir /a/2/o:gn/v/p/j %&
:: 4 colums
d4=*dir /a/4/o:gn/v/p/j/b %&
:: Only subdirs...
dd=*dir /a:d/m/w/v

:: Here is one that shows the most recent files of your directory first.
dnew=*dir /2av /o:rd | *list /s
:: Make it scrollable with list
dl=*dir %& | *list /s
:: Now here is one that only shows executables and starts them if selected.
dx=*dir/1/B/D *.exe;*.com;*.bat;*.btm > %temp\_alsdir.tmp%+*set _exe=%@select[%temp\_alsdir.tmp,4,5,19,20, Execute ]%+%_exe%+*unset/q _exe=%+*del/q %temp\_alsdir.tmp >& nul
:: This one shows you all those doc files in a download and lets you select
:: the one to show.
ddoc=*dir/1/B/D *.doc;*.txt;*.me;*.1st;*.asc > %temp\_alsdir.tmp%+*set _doc=%@select[%temp\_alsdir.tmp,4,5,19,20, Read ]%+if [%_doc] != [] *list %_doc%+*unset/q _doc%+*del %temp\_alsdir.tmp >& nul

:: use the 4DOS "list" for the old DOS "more":
more=*list /s
:: and rename list to something else before we choose another lister.
see=*list

:: Here is one for V. Buergs LIST.COM, a very useful utility everyone
:: should have in my opinion... It only list the files from [filespec] %1.
l*ist=c:\tools\list.com %1 /M /D

:: This one calls my editor with all files from [filespec] %&
:: (could be more than one)...
e*dit=set app=TSE editor 2.0%+c:\tse\e.exe %&%+set app=

:: SSET: If you type 'set' to add an environment variable or to give a list
:: of environment variables set, it will display the free environment space
:: on the next line (it'll also page the list). If SET is called from a
:: batch file, then it won't display the free environment space.
:: Author: Paul Smith 100023,25
sset=*set /p %& %+iff %_batch==0 then %+echo. %+ echo %_env Byte Environment Free%+endiff
:: The same for aliases
sals=*alias /p %& %+iff %_batch==0 then %+ echo.%+ echo %_alias Byte Alias Space Free %+endiff

:: Run your set sorted through LIST:
setl=*set | sort | *list/s

:: Run your tree through LIST:
treel=*tree %& | *list /s

:: If you want to run a program which uses DOS commands without inter-
:: ference from aliases, use this to unalias all commands :
run=setdos /x-1 %+%& %+setdos /x0
:: To test a new batch step for step:
tst=setdos /y1 %+%& %+setdos /y0 %+setdos /x0

rescan=*cdd /s cdefghij
cd=*cdd
md=*md %& && rescan
rd=*rd %& && rescan
nd=*md %1 && *cd %1 %+ rescan
ddel=iff isdir %1 then %+ *del /q/s/x/y/z %1\*.* >&> nul %+ if %@instr[0,2,%1] ne a: rescan %+ else %+ echo %1 is not a directory %+ endiff
dren=iff isdir %1 then %+ *ren %1 %2 %+ rescan %+ else %+ echo %1 is not a directory %+endiff
unknown_cmd=set _fd=%_cwd %+ *cdd %1 >& nul %+ if %_cwd eq %_fd (beep %+ color bri gre on blu %+ echo. %+ echo %@upper[%1]? Me? How? Why? %+ echo. %+ unset _fd %+ color bri whi on blu)

:: Filter all files older/newer than n days:
older=%2& /[d01.01.80,%@eval[%@date[%_date]-%1]]
newer=%2& /[d-%1]

