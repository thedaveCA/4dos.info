With CreateObject("WScript.Shell")
   .AppActivate("4DOS")
   If .AppActivate("Suchen nach") Then .Sendkeys "{enter}"
End with

With CreateObject("WScript.Shell")
   .AppActivate("4DOS")
   If .AppActivate("Search for") Then .Sendkeys "{enter}"
End with
