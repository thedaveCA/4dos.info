!TCL=146, 4dos internal vars
!TITLE=4dos internal vars
!SORT=Y

!TEXT=* Substitutes command separator
%+
!
!TEXT=* Substitutes escape character
%=
!
!TEXT=* Exit code, last external program
%?
!
!TEXT=* Reason for external program termination
%??
!
!TEXT=4DOS version (5.0, 5.01, etc.)
%_4VER
!
!TEXT=* Exit code, last internal command
%_?
!
!TEXT=Free alias space in bytes
%_ALIAS
!
!TEXT=* ANSI driver flag (0 or 1)
%_ANSI
!
!TEXT=* APM AC line status (on, off, or unknown)
%_APMAC
!
!TEXT=* APM battery status
%_APMBATT
!
!TEXT=* APM battery life (0 - 100% or unknown)
%_APMLIFE
!
!TEXT=Batch nesting level
%_BATCH
!
!TEXT=Current line number in current batch file
%_BATCHLINE
!
!TEXT=Name of current batch file
%_BATCHNAME
!
!TEXT=Background color at cursor position
%_BG
!
!TEXT=Boot drive letter, without a colon
%_BOOT
!
!TEXT=Current cursor shape in insert mode
%_CI
!
!TEXT=Current cursor shape in overstrike mode
%_CO
!
!TEXT=Current code page number
%_CODEPAGE
!
!TEXT=Current cursor column
%_COLUMN
!
!TEXT=Screen width
%_COLUMNS
!
!TEXT=Current country code
%_COUNTRY
!
!TEXT=CPU type (86, 186, 200, 386, 486, 586)
%_CPU
!
!TEXT=Current drive and directory (d:\path)
%_CWD
!
!TEXT=Current drive and directory with \ (d:\path\)
%_CWDS
!
!TEXT=Current directory (\path)
%_CWP
!
!TEXT=Current directory with \ (\path\)
%_CWPS
!
!TEXT=* Current date (mm-dd-yy)
%_DATE
!
!TEXT=Day of the month (1 - 31)
%_DAY
!
!TEXT=Current drive (C, D, etc.)
%_DISK
!
!TEXT=Name of file used to store file descriptions
%_DNAME
!
!TEXT=* Operating system (DOS, OS2, etc.)
%_DOS
!
!TEXT=* Operating system version (5.0, 6.0, etc.)
%_DOSVER
!
!TEXT=Day of the week (Mon, Tue, Wed, etc.)
%_DOW
!
!TEXT=Numeric day of the week (Sun = 1, etc.)
%_DOWI
!
!TEXT=Day of the year (1 - 366)
%_DOY
!
!TEXT=DPMI version number
%_DPMI
!
!TEXT=DESQview loaded flag (0 or 1)
%_DV
!
!TEXT=Free environment space in bytes
%_ENV
!
!TEXT=Foreground color at cursor position
%_FG
!
!TEXT=Current history log file name
%_HLOGFILE
!
!TEXT=Hour (0 - 23)
%_HOUR
!
!TEXT=Keystroke waiting in buffer (0 or 1)
%_KBHIT
!
!TEXT=KSTACK.COM load status (0 or 1)
%_KSTACK
!
!TEXT=Last possible drive (E, F, etc.)
%_LASTDISK
!
!TEXT=Current log file name
%_LOGFILE
!
!TEXT=Minute (0 - 59)
%_MINUTE
!
!TEXT=Monitor type (mono or color)
%_MONITOR
!
!TEXT=Month of the year (1 - 12)
%_MONTH
!
!TEXT=Mouse driver loaded flag (0 or 1)
%_MOUSE
!
!TEXT=Coprocessor type (0, 87, 287, 387)
%_NDP
!
!TEXT=Current cursor row
%_ROW
!
!TEXT=Screen height
%_ROWS
!
!TEXT=Second (0 - 59)
%_SECOND
!
!TEXT=Shell level (0, 1, 2, ...)
%_SHELL
!
!TEXT=* Swapping state (XMS, EMS, Disk, None, or off)
%_SWAPPING
!
!TEXT=* Last DOS error
%_SYSERR
!
!TEXT=* Current time (hh:mm:ss)
%_TIME
!
!TEXT=* Transient shell flag (0 or 1)
%_TRANSIENT
!
!TEXT=Video board type (mono, cga, ega, or vga)
%_VIDEO
!
!TEXT=* Microsoft Windows mode
%_WIN
!
!TEXT=* OS/2 DOS session window title
%_WINTITLE
!
!TEXT=Year (1980 - 2099)
%_YEAR
!
