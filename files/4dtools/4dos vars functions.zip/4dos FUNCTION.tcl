!TCL=147, 4dos internal functions
!TITLE=4dos internal functions
!SORT=Y


!TEXT=Value of an alias
%@ALIAS[name]
!
!TEXT=Numeric ASCII value for a character
%@ASCII[c]
!
!TEXT=File attribute test (0 or 1)
%@ATTRIB[filename,[nrhsda]]
!
!TEXT=CD-ROM drive detection (0 or 1)
%@CDROM[d:]
!
!TEXT=Character value for numeric ASCII
%@CHAR[n]
!
!TEXT=Line from the clipboard
%@CLIP[n]
!
!TEXT=Inserts commas in a number
%@COMMA[n]
!
!TEXT=Base conversion
%@CONVERT[in,out,value]
!
!TEXT=Convert date to number of days
%@DATE[mm-dd-yy]
!
!TEXT=Day of the month
%@DAY[mm-dd-yy]
!
!TEXT=Decremented value of a variable
%@DEC[%var]
!
!TEXT=File description
%@DESCRIPT[filename]
!
!TEXT=Character device detection
%@DEVICE[name]
!
!TEXT=Free disk space
%@DISKFREE[d:,b|k|m]
!
!TEXT=Total disk space
%@DISKTOTAL[d:,b|k|m]
!
!TEXT=Used disk space
%@DISKUSED[d:,b|k|m]
!
!TEXT=Free DOS memory
%@DOSMEM[b|k|m]
!
!TEXT=Day of the week
%@DOW[mm-dd-yy]
!
!TEXT=Numeric day of the week
%@DOWI[mm-dd-yy]
!
!TEXT=Numeric day of the year
%@DOY[mm-dd-yy]
!
!TEXT=Free EMS memory
%@EMS[b|k|m]
!
!TEXT=Arithmetic calculations
%@EVAL[expression]
!
!TEXT=Execute a command
%@EXEC[command]
!
!TEXT=Execute, return string
%@EXECSTR[command]
!
!TEXT=Wildcard expansion
%@EXPAND[filename,[nrhsda]]
!
!TEXT=File extension
%@EXT[filename]
!
!TEXT=Free extended memory
%@EXTENDED[b|k|m]
!
!TEXT=File age (date and time)
%@FILEAGE[filename]
!
!TEXT=Close a file
%@FILECLOSE[n]
!
!TEXT=File date
%@FILEDATE[filename]
!
!TEXT=File name and extension
%@FILENAME[filename]
!
!TEXT=Open a file
%@FILEOPEN[filename,mode]
!
!TEXT=Read line or bytes from a file
%@FILEREAD[n [,length]]
!
!TEXT=Count files matching a wildcard
%@FILES[filename [,-nrhsda]]
!
!TEXT=Move file pointer to an offset
%@FILESEEK[n,offset,start]
!
!TEXT=Move file pointer to a line number
%@FILESEEKL[n,line]
!
!TEXT=Size of files matching a wildcard
%@FILESIZE[filename,b|k|m]
!
!TEXT=File time
%@FILETIME[filename]
!
!TEXT=Write next line to a file
%@FILEWRITE[n,text]
!
!TEXT=Write bytes to a file
%@FILEWRITEB[n,length,string]
!
!TEXT=Close search handle
%@FINDCLOSE[filename]
!
!TEXT=Find first matching file
%@FINDFIRST[filename[,-nrhsda]]
!
!TEXT=Find next matching file
%@FINDNEXT[filename[,-nrhsda]]
!
!TEXT=Formats (justifies) a string
%@FORMAT[[-][x][.y],string]
!
!TEXT=Full file name with path
%@FULL[filename]
!
!TEXT=Evaluates a test condition
%@IF[condition,true,false]
!
!TEXT=Incremented value of a variable
%@INC[%var]
!
!TEXT=Position of one string in another
%@INDEX[string1,string2]
!
!TEXT=Insert one string into another
%@INSERT[n,string1,string2]
!
!TEXT=Extract a substring
%@INSTR[start,length,string]
!
!TEXT=Integer part of a number
%@INT[n]
!
!TEXT=Volume label
%@LABEL[d:]
!
!TEXT=Leftmost characters of a string
%@LEFT[n,string]
!
!TEXT=Length of a string
%@LEN[string]
!
!TEXT=Long path and filename
%@LFN[filename]
!
!TEXT=Read a random line from a file
%@LINE[filename,n]
!
!TEXT=Count lines in a file
%@LINES[filename]
!
!TEXT=Convert string to lower case
%@LOWER[string]
!
!TEXT=Printer port ready status (0 or 1)
%@LPT[n]
!
!TEXT=Convert date/time to file date/time
%@MAKEAGE[date[,time]]
!
!TEXT=Convert number of days to date
%@MAKEDATE[n]
!
!TEXT=Convert number of seconds to time
%@MAKETIME[n]
!
!TEXT=Value from master environment
%@MASTER[varname]
!
!TEXT=Month of the year
%@MONTH[mm-dd-yy]
!
!TEXT=File name without path or extension
%@NAME[filename]
!
!TEXT=Test if a string is numeric
%@NUMERIC[string]
!
!TEXT=File path without name
%@PATH[filename]
!
!TEXT=Generate a random integer
%@RANDOM[min,max]
!
!TEXT=Character from the screen
%@READSCR[row,col,len]
!
!TEXT=Drive ready status (0 or 1)
%@READY[d:]
!
!TEXT=Remote drive detection (0 or 1)
%@REMOTE[d:]
!
!TEXT=Removable drive detection (0 or 1)
%@REMOVABLE[d:]
!
!TEXT=Repeat a character
%@REPEAT[c,n]
!
!TEXT=Replace within a string
%@REPLACE[str1,str2,str3]
!
!TEXT=Rightmost characters of a string
%@RIGHT[n,string]
!
!TEXT=Path search
%@SEARCH[filename]
!
!TEXT=Menu selection
%@SELECT[file,t,l,b,r,title]
!
!TEXT=Short path and filename
%@SFN[filename]
!
!TEXT=Strip characters from a string
%@STRIP[chars,string]
!
!TEXT=Extract a substring
%@SUBSTR[string,start,length]
!
!TEXT=Convert time to number of seconds
%@TIME[hh:mm:ss]
!
!TEXT=Elapsed time of specified timer
%@TIMER[n]
!
!TEXT=Remove blanks from a string
%@TRIM[string]
!
!TEXT=True name of a file
%@TRUENAME[filename]
!
!TEXT=Create file with unique name
%@UNIQUE[d:\path]
!
!TEXT=Convert string to upper case
%@UPPER[string]
!
!TEXT=Wildcard comparison
%@WILD[str1,str2]
!
!TEXT=Extract a word from a string
%@WORD[["sep",]n,string]
!
!TEXT=Counts number of words in a string
%@WORDS[["sep",]string]
!
!TEXT=Free XMS memory
%@XMS[b|k|m]
!
!TEXT=Year number (2 digits)
%@YEAR[mm-dd-yy]
!
