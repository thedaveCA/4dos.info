@echo off
rem 4DOS batch file for Windows Startup
echo %0 %1 %2 %3 %4 %5 %6 %7 %8 %9 CurrentDir [%_CWD] Shell(%_shell)
history > c:\4dos\4winhist >&> nul
quit
