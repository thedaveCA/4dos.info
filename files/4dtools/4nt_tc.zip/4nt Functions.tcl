!TCL=721, 4NT TC v6 Variable Functions by Mike Applebee
!TITLE=4NT TC v6 Variable Functions
!SORT=N

!TEXT=@ABS - Absolute value of n �
%@ABS[\^]
!
!TEXT=@AGEDATE - Converts a filetime into date and time �
%@AGEDATE[\^]
!
!TEXT=@ALIAS - Value of an alias �
%@ALIAS[\^]
!
!TEXT=@ALTNAME - Returns the short name for the file. �
%@ALTNAME[\^]
!
!TEXT=@ASCII - Numeric ASCII value for a character �
%@ASCII[\^]
!
!TEXT=@ATTRIB - Test or return file attributes �
%@ATTRIB[\^]
!
!TEXT=@CAPS - Capitalize first character of each word �
%@CAPS[\^]
!
!TEXT=@CDROM - CD ROM drive detection (0 or 1) �
%@CDROM[\^]
!
!TEXT=@CEILING - Smallest integer not less th � n
%@CEILING[\^]
!
!TEXT=@CHAR - Character value for numeric ASCII �
%@CHAR[\^]
!
!TEXT=@CLIP - Returns line n from clipboard �
%@CLIP[\^]
!
!TEXT=@CLIPW - Write string to the clipboard �
%@CLIPW[\^]
!
!TEXT=@COLOR - Returns the RGB value of a color �
%@COLOR[\^]
!
!TEXT=@COMMA - Insert commas into a number �
%@COMMA[\^]
!
!TEXT=@CONSOLE - Identify console sessions �
%@CONSOLE[\^]
!
!TEXT=@CONVERT - Convert value from input base to output base �
%@CONVERT[\^]
!
!TEXT=@CRC32 - File CRC �
%@CRC32[\^]
!
!TEXT=@DATE - Convert date to number of days �
%@DATE[\^]
!
!TEXT=@DAY - Returns day of month for date �
%@DAY[\^]
!
!TEXT=@DEC - Decrement a numeric value by 1 �
%@DEC[\^]
!
!TEXT=@DECIMAL - Decimal portion of a number �
%@DECIMAL[\^]
!
!TEXT=@DESCRIPT - File description �
%@DESCRIPT[\^]
!
!TEXT=@DEVICE - Character device detection �
%@DEVICE[\^]
!
!TEXT=@DIGITS - Tests if string is all digits �
%@DIGITS[\^]
!
!TEXT=@DIRSTACK - Display directory stack entry �
%@DIRSTACK[\^]
!
!TEXT=@DISKFREE - Free disk space �
%@DISKFREE[\^]
!
!TEXT=@DISKTOTAL - Total disk space �
%@DISKTOTAL[\^]
!
!TEXT=@DISKUSED - Used disk space �
%@DISKUSED[\^]
!
!TEXT=@DOW - Returns day of week for date �
%@DOW[\^]
!
!TEXT=@DOWF - Full name of day of week �
%@DOWF[\^]
!
!TEXT=@DOWI - Returns day of week as integer �
%@DOWI[\^]
!
!TEXT=@DOY - Returns day of year for date �
%@DOY[\^]
!
!TEXT=@ENUMSERVERS - Identify server names on a network �
%@ENUMSERVERS[\^]
!
!TEXT=@ENUMSHARES - Identify sharenames on a server �
%@ENUMSHARES[\^]
!
!TEXT=@ERRTEXT - Windows error description �
%@ERRTEXT[\^]
!
!TEXT=@EVAL - Arithmetic calculations �
%@EVAL[\^]
!
!TEXT=@EXEC - Execute a command �
%@EXEC[\^]
!
!TEXT=@EXECSTR - Execute a command and return the first output line �
%@EXECSTR[\^]
!
!TEXT=@EXETYPE - Application type �
%@EXETYPE[\^]
!
!TEXT=@EXPAND - Returns all names that match filename �
%@EXPAND[\^]
!
!TEXT=@EXT - File extension �
%@EXT[\^]
!
!TEXT=@FIELD - Extract a field from a string �
%@FIELD[\^]
!
!TEXT=@FIELDS - Count fields in a string �
%@FIELDS[\^]
!
!TEXT=@FILEAGE - File age (date and time) �
%@FILEAGE[\^]
!
!TEXT=@FILECLOSE - Close a file handle �
%@FILECLOSE[\^]
!
!TEXT=@FILEDATE - File date �
%@FILEDATE[\^]
!
!TEXT=@FILENAME - File name and extension �
%@FILENAME[\^]
!
!TEXT=@FILEOPEN - Open a file handle �
%@FILEOPEN[\^]
!
!TEXT=@FILEREAD - Read next line from a file handle �
%@FILEREAD[\^]
!
!TEXT=@FILES - Count files matching a wildcard �
%@FILES[\^]
!
!TEXT=@FILESEEKL - Move a file handle pointer to a specified line �
%@FILESEEKL[\^]
!
!TEXT=@FILESIZE - Size of files matching a wildcard �
%@FILESIZE[\^]
!
!TEXT=@FILETIME - File time �
%@FILETIME[\^]
!
!TEXT=@FILEWRITE - Write next line to a file handle �
%@FILEWRITE[\^]
!
!TEXT=@FILEWRITEB - Write data to a file handle �
%@FILEWRITEB[\^]
!
!TEXT=@FINDCLOSE - Closes the search handle. �
%@FINDCLOSE[\^]
!
!TEXT=@FINDFIRST - Find first matching file �
%@FINDFIRST[\^]
!
!TEXT=@FINDNEXT - Find next matching file �
%@FINDNEXT[\^]
!
!TEXT=@FLOOR - Largest integer not larger th � n
%@FLOOR[\^]
!
!TEXT=@FORMAT - Formats datstr according to fmstr �
%@FORMAT[\^]
!
!TEXT=@FORMATN - Format a numeric value �
%@FORMATN[\^]
!
!TEXT=@FSTYPE - File system type (FAT, NTFS, CDFS, etc.) �
%@FSTYPE[\^]
!
!TEXT=@FULL - Full file name with path �
%@FULL[\^]
!
!TEXT=@FUNCTION - Definition of function n �e
%@FUNCTION[\^]
!
!TEXT=@GETDIR - Prompt for a directory name. �
%@GETDIR[\^]
!
!TEXT=@GETFILE - Prompt for a path and file name. �
%@GETFILE[\^]
!
!TEXT=@GETFOLDER - Folder name from tree view. �
%@GETFOLDER[\^]
!
!TEXT=@HISTORY - Return a line or word from the command hist �y
%@HISTORY[\^]
!
!TEXT=@IDOW - Returns localized day of week for date �
%@IDOW[\^]
!
!TEXT=@IDOWF - Full localized name of day of week for date �
%@IDOWF[\^]
!
!TEXT=@IF - Evaluates an expression �
%@IF[\^]
!
!TEXT=@INC - Increment a numeric value by 1 �
%@INC[\^]
!
!TEXT=@INDEX - Offset of string2 within string1 �
%@INDEX[\^]
!
!TEXT=@INIREAD - Return an entry from an .INI file �
%@INIREAD[\^]
!
!TEXT=@INIWRITE - Write an entry in an .INI file �
%@INIWRITE[\^]
!
!TEXT=@INSTR - Extract a substring �
%@INSTR[\^]
!
!TEXT=@INT - Integer part of a number �
%@INT[\^]
!
!TEXT=@IPADDRESS - Returns the numeric IP for a host name �
%@IPADDRESS[\^]
!
!TEXT=@IPNAME - Returns the host name for a numeric IP �
%@IPNAME[\^]
!
!TEXT=@ISALNUM - Test for alphanumeric characters �
%@ISALNUM[\^]
!
!TEXT=@ISALPHA - Test for alphabetic characters �
%@ISALPHA[\^]
!
!TEXT=@ISASCII - Test for ASCII characters �
%@ISASCII[\^]
!
!TEXT=@ISCNTRL - Test for control characters �
%@ISCNTRL[\^]
!
!TEXT=@ISDIGIT - Test for decimal digits �
%@ISDIGIT[\^]
!
!TEXT=@ISPRINT - Test for printable characters �
%@ISPRINT[\^]
!
!TEXT=@ISPUNCT - Test for punctuation characters �
%@ISPUNCT[\^]
!
!TEXT=@ISSPACE - Test for white space characters �
%@ISSPACE[\^]
!
!TEXT=@ISXDIGIT - Test for hexadecimal digits �
%@ISXDIGIT[\^]
!
!TEXT=@LABEL - Volume label �
%@LABEL[\^]
!
!TEXT=@LEFT - Returns the left end of string �
%@LEFT[\^]
!
!TEXT=@LEN - Length of a string �
%@LEN[\^]
!
!TEXT=@LFN - Returns long name for a short filename �
%@LFN[\^]
!
!TEXT=@LINE - Read a random line from a file �
%@LINE[\^]
!
!TEXT=@LINES - Count lines in a file �
%@LINES[\^]
!
!TEXT=@LTRIM - Removes specified leading characters. �
%@LTRIM[\^]
!
!TEXT=@MAKEAGE - Convert date to file timestamp format �
%@MAKEAGE[\^]
!
!TEXT=@MAKETIME - Convert number of seconds to time �
%@MAKETIME[\^]
!
!TEXT=@MD5 - Computes MD5 hash for a string or file �
%@MD5[\^]
!
!TEXT=@MIN - Smallest integer in the list �
%@MIN[\^]
!
!TEXT=@MONTH - Returns month for date �
%@MONTH[\^]
!
!TEXT=@NAME - File name without path or extension �
%@NAME[\^]
!
!TEXT=@NUMERIC - Test if a string is numeric �
%@NUMERIC[\^]
!
!TEXT=@OPTION - Current .INI file directive value �
%@OPTION[\^]
!
!TEXT=@PATH - File path without name �
%@PATH[\^]
!
!TEXT=@PING - Response time from a host �
%@PING[\^]
!
!TEXT=@RANDOM - Generate a random integer �
%@RANDOM[\^]
!
!TEXT=@READSCR - Read characters from the screen �
%@READSCR[\^]
!
!TEXT=@READY - Drive ready status (0 or 1) �
%@READY[\^]
!
!TEXT=@REGCREATE - Create registry subkey �
%@REGCREATE[\^]
!
!TEXT=@REGDELKEY - Delete a registry key and its subkeys �
%@REGDELKEY[\^]
!
!TEXT=@REGEXIST - Test if a registry key exists �
%@REGEXIST[\^]
!
!TEXT=@REGQUERY - Read value from registry �
%@REGQUERY[\^]
!
!TEXT=@REGSET - Write value to registry �
%@REGSET[\^]
!
!TEXT=@REGSETENV - Write value to registry and broadcast change. �
%@REGSETENV[\^]
!
!TEXT=@REMOTE - Remote (network) drive detection (0 or 1) �
%@REMOTE[\^]
!
!TEXT=@REMOVABLE - Removable drive detection (0 or 1) �
%@REMOVABLE[\^]
!
!TEXT=@REPEAT - Repeat a character �
%@REPEAT[\^]
!
!TEXT=@REPLACE - Replace string1 with string2 in text �
%@REPLACE[\^]
!
!TEXT=@REXX - Calls REXX to execute expression �
%@REXX[\^]
!
!TEXT=@RIGHT - Returns the right end of string. �
%@RIGHT[\^]
!
!TEXT=@RTRIM - Removes specified trailing characters. �
%@RTRIM[\^]
!
!TEXT=@SEARCH - Path search �
%@SEARCH[\^]
!
!TEXT=@SEARCH - Path search �
%@SEARCH[\^]
!
!TEXT=@SELECT - Menu selection �
%@SELECT[\^]
!
!TEXT=@SFN - Returns short name for a long filename �
%@SFN[\^]
!
!TEXT=@STRIP - Strips all characters in char from string �
%@STRIP[\^]
!
!TEXT=@SUBST - Substitute a string within another string �
%@SUBST[\^]
!
!TEXT=@SUBSTR - Extract a substring �
%@SUBSTR[\^]
!
!TEXT=@TIME - Convert time to number of seconds �
%@TIME[\^]
!
!TEXT=@TIMER - Get split time from timer. �
%@TIMER[\^]
!
!TEXT=@TRIM - Remove blanks from a string �
%@TRIM[\^]
!
!TEXT=@TRUENAME - Find "true" name for a file �
%@TRUENAME[\^]
!
!TEXT=@TRUENAME - Find "true" name for a file �
%@TRUENAME[\^]
!
!TEXT=@UNICODE - Numeric UNICODE value for a character �
%@UNICODE[\^]
!
!TEXT=@UNIQUE - Create file with unique name �
%@UNIQUE[\^]
!
!TEXT=@UPPER - Convert string to upper case �
%@UPPER[\^]
!
!TEXT=@VERINFO - Executable file version information �
%@VERINFO[\^]
!
!TEXT=@WATTRIB - Test or return file attributes, including Windows 2000 / XP attributes �
%@WATTRIB[\^]
!
!TEXT=@WILD - Compares strings using wildcards �
%@WILD[\^]
!
!TEXT=@WINCLASS - Title of first window with classname �
%@WINCLASS[\^]
!
!TEXT=@WINEXENAME - Executable name for window �
%@WINEXENAME[\^]
!
!TEXT=@WININFO - Current system informati �
%@WININFO[\^]
!
!TEXT=@WINMETRICS - Windows system metrics �
%@WINMETRICS[\^]
!
!TEXT=@WINSTATE - Current state of window �
%@WINSTATE[\^]
!
!TEXT=@WINSYSTEM - Set/get windows system parameters �
%@WINSYSTEM[\^]
!
!TEXT=@WORD - Extract a word from a string �
%@WORD[\^]
!
!TEXT=@WORDS - Count words in a string �
%@WORDS[\^]
!
!TEXT=@YEAR - Returns year for date �
%@YEAR[\^]
!
