!TCL=722, 4NT TC v6 Internal Variables by Mike Applebee
!TITLE=4NT TC v6 Internal Variable
!SORT=N

!TEXT=+ - Substitutes command separator �
%+
!
!TEXT== - Substitutes command processor escape character �
%=
!
!TEXT=_4ver - Command processor version �
%_4ver
!
!TEXT=_? - Exit code, last internal command �
%_?
!
!TEXT=_acstatus - AC line status �
%_acstatus
!
!TEXT=_ansi - ANSI X3.64 status �
%_ansi
!
!TEXT=_batch - Batch nesting level �
%_batch
!
!TEXT=_batchline - Line number in current batch file. �
%_batchline
!
!TEXT=_batchname - Full path and filename of current batch file. �
%_batchname
!
!TEXT=_battery - Battery status �
%_battery
!
!TEXT=_batterylife - Remaining battery life, seconds �
%_batterylife
!
!TEXT=_batterypercent - Remaining battery life, % �
%_batterypercent
!
!TEXT=_bg - Background color at cursor position �
%_bg
!
!TEXT=_boot - Boot drive letter, without a colon �
%_boot
!
!TEXT=_build - Build number �
%_build
!
!TEXT=_capslock - CapsLock on �
%_capslock
!
!TEXT=_childpid - Process ID of most recent child process �
%_childpid
!
!TEXT=_ci - Current text cursor shape in insert mode �
%_ci
!
!TEXT=_cmdline - Current command line �
%_cmdline
!
!TEXT=_cmdproc - Command processor name �
%_cmdproc
!
!TEXT=_co - Current text cursor shape in overstrike mode �
%_co
!
!TEXT=_codepage - Current code page number �
%_codepage
!
!TEXT=_column - Current cursor column �
%_column
!
!TEXT=_columns - Virtual screen width �
%_columns
!
!TEXT=_country - Current country code �
%_country
!
!TEXT=_cpu - CPU type �
%_cpu
!
!TEXT=_cpuusage - CPU time usage (percent) �
%_cpuusage
!
!TEXT=_ctrl - Ctrl key depressed �
%_ctrl
!
!TEXT=_cwd - Current drive and directory �
%_cwd
!
!TEXT=_cwds - Current drive and directory with trailing \ �
%_cwds
!
!TEXT=_cwp - Current directory �
%_cwp
!
!TEXT=_cwps - Current directory with trailing \ �
%_cwps
!
!TEXT=_date - Current date �
%_date
!
!TEXT=_day - Current day of the month �
%_day
!
!TEXT=_detachpid - Process ID of most recent detached process �
%_detachpid
!
!TEXT=_disk - Current drive �
%_disk
!
!TEXT=_dname - Name of the description file. �
%_dname
!
!TEXT=_dos - Operating system type �
%_dos
!
!TEXT=_dosver - Operating system version �
%_dosver
!
!TEXT=_dow - Current day of the week, English, short �
%_dow
!
!TEXT=_dowf - Current day of the week, English, full �
%_dowf
!
!TEXT=_dowi - Current day of the week as an integer �
%_dowi
!
!TEXT=_doy - Current day of the year �
%_doy
!
!TEXT=_echo - Echo status �
%_echo
!
!TEXT=_fg - Foreground color at cursor position �
%_fg
!
!TEXT=_ftperror - Last FTP error code �
%_ftperror
!
!TEXT=_hlogfile - Current history log file name �
%_hlogfile
!
!TEXT=_host - Host name of local computer. �
%_host
!
!TEXT=_hour - Current hour �
%_hour
!
!TEXT=_hwprofile - Windows hardware profile if defin �
%_hwprofile
!
!TEXT=_idow - Current day of the week, local language, short �
%_idow
!
!TEXT=_imonth - Current month name, local language, short �
%_imonth
!
!TEXT=_imonthf - Current month name, local language, full �
%_imonthf
!
!TEXT=_ininame - Full pathname of the current INI file �
%_ininame
!
!TEXT=_ip - IP address(es) of local computer. �
%_ip
!
!TEXT=_isodate - Current date in ISO 9601 format �
%_isodate
!
!TEXT=_kbhit - Returns 1 if and only if a keyboard input character is waiting �
%_kbhit
!
!TEXT=_lalt - left Alt key depressed �
%_lalt
!
!TEXT=_lastdisk - Last valid drive �
%_lastdisk
!
!TEXT=_lctrl - left Ctrl key depressed �
%_lctrl
!
!TEXT=_logfile - Current log file name �
%_logfile
!
!TEXT=_lshift - left Shift key depressed �
%_lshift
!
!TEXT=_minute - Current minute �
%_minute
!
!TEXT=_month - Current month of the year as integer �
%_month
!
!TEXT=_monthf - Current month of the year, English, full �
%_monthf
!
!TEXT=_numlock - NumLock on �
%_numlock
!
!TEXT=_pid - the command processor process ID (numeric) �
%_pid
!
!TEXT=_pipe - 1 if current process is running in a p otherwise �
%_pipe
!
!TEXT=_ppid - Process ID of parent process �
%_ppid
!
!TEXT=_rctrl - right Ctrl key depressed �
%_rctrl
!
!TEXT=_row - Current cursor row �
%_row
!
!TEXT=_rows - Screen height �
%_rows
!
!TEXT=_rshift - right Shift key depressed �
%_rshift
!
!TEXT=_scrolllock - ScrollLock on �
%_scrolllock
!
!TEXT=_second - Current second �
%_second
!
!TEXT=_selected - (TC) First line of highlighte �text
%_selected
!
!TEXT=_shell - Shell level �
%_shell
!
!TEXT=_shift - Shift key depressed �
%_shift
!
!TEXT=_shralias - 1 if SHRALIAS is loaded �
%_shralias
!
!TEXT=_startpath - Startup directory of current shell. �
%_startpath
!
!TEXT=_syserr - Latest Windows error code �
%_syserr
!
!TEXT=_time - Current time �
%_time
!
!TEXT=_transient - 1 if current process is a transient 0 otherwise �
%_transient
!
!TEXT=_unicode - 1 if shell uses unicode for redirected ou0 otherwise �
%_unicode
!
!TEXT=_windir - Windows directory pathname �
%_windir
!
!TEXT=_winname - Name of local computer �
%_winname
!
!TEXT=_winsysdir - Windows system directory pathname �
%_winsysdir
!
!TEXT=_winticks - Milliseconds since Windows was started �
%_winticks
!
!TEXT=_wintitle - Current window title �
%_wintitle
!
!TEXT=_winuser - Name of current user. �
%_winuser
!
!TEXT=_winver - Windows version number �
%_winver
!
!TEXT=_xpixels - Physical screen horizontal size in pixels �
%_xpixels
!
!TEXT=_year - Current year �
%_year
!
!TEXT=_ypixels - Physical screen vertical size in pixels �
%_ypixels
!
!TEXT=errorlevel - Exit code, last external program �
%errorlevel
!
