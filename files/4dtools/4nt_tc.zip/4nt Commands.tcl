!TCL=723, 4NT TC v6 Internal Commands by Mike Applebee
!TITLE=4NT TC v6 Internal Commands
!SORT=N

!TEXT=? - Display internal commands 
%?[\^]
!
!TEXT=ACTIVATE - Activate or set window state 
%ACTIVATE[\^]
!
!TEXT=ALIAS - Define or display aliases 
%ALIAS[\^]
!
!TEXT=ASSOC - Windows file associations 
%ASSOC[\^]
!
!TEXT=ATTRIB - Change or display file attributes 
%ATTRIB[\^]
!
!TEXT=BATCOMP - Batch file compression    
%BATCOMP[\^]
!
!TEXT=BDEBUGGER - Batch file debugger       
%BDEBUGGER[\^]
!
!TEXT=BEEP - Beep the speaker          
%BEEP[\^]
!
!TEXT=BREAK - Define or display C-C state 
%BREAK[\^]
!
!TEXT=CALL - Call another batch file   
%CALL[\^]
!
!TEXT=CANCEL - End batch file processing 
%CANCEL[\^]
!
!TEXT=CD - Display or change directory 
%CD[\^]
!
!TEXT=CDD - Change drive and directory 
%CDD[\^]
!
!TEXT=CHCP - Display or change code page 
%CHCP[\^]
!
!TEXT=CHDIR - Display or change directory 
%CHDIR[\^]
!
!TEXT=CLS - Clear the display window  
%CLS[\^]
!
!TEXT=COLOR - Change the display colors 
%COLOR[\^]
!
!TEXT=COPY - Copy files and/or directories 
%COPY[\^]
!
!TEXT=DATE - Display or change date  
%DATE[\^]
!
!TEXT=DDEEXEC - Send DDE command        
%DDEEXEC[\^]
!
!TEXT=DEL - Delete files and/or directories 
%DEL[\^]
!
!TEXT=DELAY - Wait for specified time 
%DELAY[\^]
!
!TEXT=DESCRIBE - Display or change descriptions 
%DESCRIBE[\^]
!
!TEXT=DETACH - Start app detached      
%DETACH[\^]
!
!TEXT=DIR - Display files and/or directories 
%DIR[\^]
!
!TEXT=DIRHISTORY - Display directory history	list 
%DIRHISTORY[\^]
!
!TEXT=DIRS - Display directory stack 
%DIRS[\^]
!
!TEXT=DO - Create batch file loops 
%DO[\^]
!
!TEXT=DRAWBOX - Draw a box              
%DRAWBOX[\^]
!
!TEXT=DRAWHLINE - Draw a horizontal line  
%DRAWHLINE[\^]
!
!TEXT=DRAWVLINE - Draw a vertical line    
%DRAWVLINE[\^]
!
!TEXT=ECHO - Echo a message STDERR 
%ECHO[\^]
!
!TEXT=ECHOS - Echo a message with no CR/LF 
%ECHOS[\^]
!
!TEXT=ECHOSERR - Echo with no CR/LF to STDERR 
%ECHOSERR[\^]
!
!TEXT=ENDLOCAL - Restore from a SETLOCAL 
%ENDLOCAL[\^]
!
!TEXT=ERASE - Delete files and/or directories 
%ERASE[\^]
!
!TEXT=ESET - Edit variables or aliases 
%ESET[\^]
!
!TEXT=EVENTLOG - Write Windows event log   
%EVENTLOG[\^]
!
!TEXT=EXCEPT - Exclude files from a command 
%EXCEPT[\^]
!
!TEXT=EXIT - Exit the command          
%EXIT[\^]
!
!TEXT=FFIND - Search for files or text  
%FFIND[\^]
!
!TEXT=FOR - Repeat a command          
%FOR[\^]
!
!TEXT=FREE - Display disk space        
%FREE[\^]
!
!TEXT=FTYPE - Display or edit file type 
%FTYPE[\^]
!
!TEXT=FUNCTION - Create or edit user functions 
%FUNCTION[\^]
!
!TEXT=GLOBAL - Run command in subdirectories  
%GLOBAL[\^]
!
!TEXT=GOSUB - Call batch subroutines       
%GOSUB[\^]
!
!TEXT=GOTO - Branch in a batch file    
%GOTO[\^]
!
!TEXT=HEAD - Display beginning of file 
%HEAD[\^]
!
!TEXT=HELP - Help for internal commands 
%HELP[\^]
!
!TEXT=HISTORY - Display or change history 
%HISTORY[\^]
!
!TEXT=IF - Conditional command execution 
%IF[\^]
!
!TEXT=IFF - Conditional command execution 
%IFF[\^]
!
!TEXT=IFTP - Open FTP connection       
%IFTP[\^]
!
!TEXT=INKEY - Get a single keystroke    
%INKEY[\^]
!
!TEXT=INPUT - Get a text string         
%INPUT[\^]
!
!TEXT=KEYBD - Set keyboard toggles      
%KEYBD[\^]
!
!TEXT=KEYS - Enable or disable history list 
%KEYS[\^]
!
!TEXT=KEYSTACK - Send keystrokes to app    
%KEYSTACK[\^]
!
!TEXT=LIST - Display files             
%LIST[\^]
!
!TEXT=LOG - Save log of commands      
%LOG[\^]
!
!TEXT=MD - Create subdirectories     
%MD[\^]
!
!TEXT=MEMORY - Display memory statistics 
%MEMORY[\^]
!
!TEXT=MKDIR - Create subdirectories     
%MKDIR[\^]
!
!TEXT=MKLNK - Create NTFS hard links    
%MKLNK[\^]
!
!TEXT=MSGBOX - Popup message box            
%MSGBOX[\^]
!
!TEXT=ON - Batch file error trapping    
%ON[\^]
!
!TEXT=OPTION - Configure command processor 
%OPTION[\^]
!
!TEXT=PATH - Set or display PATH         
%PATH[\^]
!
!TEXT=PAUSE - Wait for input          
%PAUSE[\^]
!
!TEXT=PDIR - User-formatted DIR      
%PDIR[\^]
!
!TEXT=PLAYAVI - Display an .AVI file    
%PLAYAVI[\^]
!
!TEXT=PLAYSOUND - Play a sound file       
%PLAYSOUND[\^]
!
!TEXT=POPD - Restore from directory stack 
%POPD[\^]
!
!TEXT=PRINT - Print a file            
%PRINT[\^]
!
!TEXT=PROMPT - Change command  -line prompt 
%PROMPT[\^]
!
!TEXT=PUSHD - Save directory to stack 
%PUSHD[\^]
!
!TEXT=QUERYBOX - Popup input box           
%QUERYBOX[\^]
!
!TEXT=QUIT - Exit batch file           
%QUIT[\^]
!
!TEXT=RD - Remove subdirectory       
%RD[\^]
!
!TEXT=REBOOT - Reboot system             
%REBOOT[\^]
!
!TEXT=RECYCLE - Display or empty recycle bin 
%RECYCLE[\^]
!
!TEXT=REM - Remark                    
%REM[\^]
!
!TEXT=REN - Rename files or directories 
%REN[\^]
!
!TEXT=RENAME - Rename files or directories 
%RENAME[\^]
!
!TEXT=RETURN - Return from GOSUB         
%RETURN[\^]
!
!TEXT=RMDIR - Remove subdirectory          
%RMDIR[\^]
!
!TEXT=SCREEN - Position cursor              
%SCREEN[\^]
!
!TEXT=SCRPUT - Write directly to screen     
%SCRPUT[\^]
!
!TEXT=SELECT - Select files for a command 
%SELECT[\^]
!
!TEXT=SENDMAIL - Send email                
%SENDMAIL[\^]
!
!TEXT=SETDOS - Set command processor variables 
%SETDOS[\^]
!
!TEXT=SETLOCAL - Save environment and aliases 
%SETLOCAL[\^]
!
!TEXT=SHIFT - Shift batch file argument 
%SHIFT[\^]
!
!TEXT=SHORTCUT - Create a Windows shortcut 
%SHORTCUT[\^]
!
!TEXT=SHRALIAS - Share aliases             
%SHRALIAS[\^]
!
!TEXT=SMPP - Simple message transfer   
%SMPP[\^]
!
!TEXT=SNPP - Send message to pager     
%SNPP[\^]
!
!TEXT=SWITCH - Batch file switch / case  
%SWITCH[\^]
!
!TEXT=TAIL - Display end of file       
%TAIL[\^]
!
!TEXT=TASKEND - End a task                
%TASKEND[\^]
!
!TEXT=TASKLIST - Display Windows task list 
%TASKLIST[\^]
!
!TEXT=TEXT - Display text in batch file 
%TEXT[\^]
!
!TEXT=TIME - Set or display time       
%TIME[\^]
!
!TEXT=TIMER - Stopwatch                 
%TIMER[\^]
!
!TEXT=TITLE - Set window title          
%TITLE[\^]
!
!TEXT=TOUCH - Change file timestamps    
%TOUCH[\^]
!
!TEXT=TREE - Display directory tree    
%TREE[\^]
!
!TEXT=TYPE - Display files             
%TYPE[\^]
!
!TEXT=UNALIAS - Remove aliases            
%UNALIAS[\^]
!
!TEXT=UNFUNCTION - Remove user -defined functions 
%UNFUNCTION[\^]
!
!TEXT=UNSET - Remove environment variable 
%UNSET[\^]
!
!TEXT=VER - Display version           
%VER[\^]
!
!TEXT=VERIFY - Display or set disk verification 
%VERIFY[\^]
!
!TEXT=VOL - Display or set disk volume label 
%VOL[\^]
!
!TEXT=VSCRPUT - Write text vertically             
%VSCRPUT[\^]
!
!TEXT=WHICH - Display command information 
%WHICH[\^]
!
!TEXT=WINDOW - Window management                 
%WINDOW[\^]
!
!TEXT=Y - Pipe "y  -fitting"                
%Y[\^]
!