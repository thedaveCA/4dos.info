
                              4NT v5.0

                     README.TXT -- February 2003

                          JP Software Inc.
                            P.O. Box 328
                     Chestertown, MD 21620, USA

                           (410) 810-8818
                         fax (410) 810-0026
                       Email sales@jpsoft.com
                       Web http://jpsoft.com


Greetings, and thanks for trying 4NT!

This file contains a variety of information you should read before using
4NT, including:

      New Version Overview
      Installation Notes
      Files Included with this Version
      Technical Support and Downloads
      Legal Notices

Other information is available in other files:

      For ...                                See ...
      -----------------------------------    ------------
      Complete list of new features          WHATSNEW.TXT
      Introduction and Installation Guide    INTRO.TXT
      Trial version information              TRIAL.TXT
      License agreement                      LICENSE.TXT
      Product and upgrade information        PRODUCTS.TXT
      Support plan information               SUPPORT.TXT
      New customer order form                ORDERS.TXT
      Current customer upgrade order form    UPGRADES.TXT



NEW VERSION OVERVIEW
--------------------

Since the last major release we've added over 180 new features, commands,
switches, variables, and other enhancements!  The complete list of new 
features and bug fixes is in WHATSNEW.TXT.


INSTALLATION NOTES
------------------

   Our products are generally distributed as EXE files which install the
   product when run.  The EXE files are "ZIP-compatible" (i.e., they can 
   also be read as .ZIP files).  Products distributed on CD-ROM are 
   shipped with individual files visible; the files are not compressed 
   into a single .EXE file.
   
   If you have unzipped a distribution .EXE file yourself, or are using
   a CD-ROM copy, and prefer to perform the installation manually, see 
   the Introduction and Installation Guide in the file INTRO.TXT.  The 
   detailed instructions for 4NT are in Chapter 6.

   If you unzip the distribution EXE file manually, you will find many 
   extra files which are used by the installer and are not part of the 
   product itself.  You can use a command similar to the following in 
   the product directory to get rid of the extra files (this assumes 
   you have not installed other non-JP Software files in the product 
   directory which this command would delete):

     *del /qe *.dat w*.dll p*.dll unwise*.*

   If you are installing a purchased copy of 4NT from a CD-ROM, you can 
   install the files manually by copying them from the appropriate 
   directory on the CD if you wish.

   You can view any of the documentation files on-line, or copy them to
   your printer.  The Introduction and Installation Guide in INTRO.TXT
   has page breaks, headers and footers; all other documentation files
   are unpaginated ASCII text.


Registering Your Copy
---------------------

   When you purchase a new or upgrade copy of 4NT, you will receive an
   email with an attached file named 4NT.KEY  Simply double click on the 
   4NT.KEY attachment (or save it to the disk and type the file name) to 
   register 4NT with your name and serial number.  (A popup may appear 
   asking if you want to add the information in 4NT.KEY to the registry; 
   click on Yes to continue.)

   If you ordered a CD from one of our resellers, your 4NT.KEY file will
   be in the \4NT directory.

   If you are running 4NT at the time you load 4NT.KEY, your registration 
   information won't appear until you exit and restart 4NT.

   Remember to save your 4NT.KEY file in a safe place in case you need to
   reinstall 4NT.  If you have lost your registration key, you can request
   a replacement key by contacting JP Software at sales@jpsoft.com, or at 
   one of the addresses listed at the start of this file.


FILES INCLUDED
--------------

   The following files are included with 4NT 5.0:

         4NT.EXE           4NT program file
         BATCOM32.EXE      Batch file compression utility
         EXAMPLES.BTM      Sample batch file demonstrating the use
                             of variable functions and internal
                             variables
         INTRO.TXT         ASCII copy of the Introduction and
                             Installation Guide
         IPWORKS5.DLL      Internet functions support DLL
         JPHELP.CHM        4NT online help
         KEYSTACK.EXE      Program used by the KEYSTACK command
         LICENSE.TXT       License agreement
         ORDERS.TXT        New customer order form
         PRODUCTS.TXT      Product and ordering information
         README.TXT        This file
         SHRALIAS.EXE      Utility program for retention of global
                             alias and history lists
         SUPPORT.TXT       Technical support contacts, support
                             plans, and paid support options
         TRIAL.TXT         Explanation of trial version
         UPGRADES.TXT      Upgrade order form
         WHATSNEW.TXT      New features and bug fixes


TECHNICAL SUPPORT AND DOWNLOADS
-------------------------------

   Complete details on technical support, including support plans and 
   terms and conditions, are in SUPPORT.TXT, and on our web site.

   Standard, no-charge support is available through our online support 
   forum, where our support personnel can read and respond to your 
   messages, and other users can respond as well.  The forum is accessible
   via several methods; for complete details and access links see the 
   support area of our web site at http://jpsoft.com/.

   We also offer paid support options which include automatic upgrades,
   and support by private email or telephone.

   If the support forum is not accessible to you, or you need to include 
   confidential information in your support request, you can also contact 
   us at support@jpsoft.com.

   Technical support messages should always be sent as standard ASCII
   text.  Please do not transmit attached files, binary files, screen
   images, or any file over 10K bytes in size to our technical support 
   addresses unless asked to do so by our support staff.

   To download JP Software files, including maintenance updates and
   trial versions, visit:

      >> Our web site at http://jpsoft.com

      >> Our ftp site at ftp://jpsoft.com


LEGAL STUFF
-----------

Copyright 2003, JP Software Inc., All Rights Reserved.  Published by JP
Software Inc., P.O. Box 328, Chestertown, MD 21620, USA
Phone 410-810-8818, Fax 410-810-0026.

Take Command and 4DOS are registered trademarks of JP Software Inc.  4DOS 
and 4NT are JP Software Inc.'s trademarks for its family of character-mode
command processors.  JP Software, jpsoft.com, and all JP Software designs 
and logos are also trademarks of JP Software Inc.  Other product and 
company names are trademarks of their respective owners.

All prices and terms subject to change without notice.

